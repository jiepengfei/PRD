# 山道暮色战斗特效交付包

面向 EvolutionCards 的战斗特效首版，与战斗页面 v03 和人物动画接入包配套。按 [Unity 接入需求](Documentation/Unity接入需求.md) 接到现有战斗事件。

| 效果 | 透明素材 | 确认版预览 |
| --- | --- | --- |
| 剑 | `Art/Sword/sword_arc.png` | [凸弧朝向目标的横向剑光](Reference/01-剑.gif) |
| 刀 | `Art/Saber/saber_fin.png` | [冷白鲨鳍竖弧](Reference/02-刀.gif) |
| 格挡 | `Art/Block/block_cloud_shield.png` | [居中云纹白盾](Reference/03-格挡.gif) |
| 破甲状态 | `Art/ArmorBreak/armor_shield.png`、`armor_shield_cracked.png` | [居中红盾微裂](Reference/04-破甲状态.gif) |
| 蓄能 | `Art/Charge/charge_beam.png`、`charge_ribbon_strip.png` | [四道蓝光和环绕气流](Reference/05-蓄能.gif) |
| 回血 | `Art/Heal/heal_plus.png`、`heal_particle.png` | [绿色加号和光粒](Reference/06-回血.gif) |

PNG 为 256 × 256 透明素材，按确认预览的轮廓重绘，色彩与透明边缘在 Unity 里校准。GIF 是节拍和构图参考。运行时用独立特效组件、透明素材和曲线合成。
