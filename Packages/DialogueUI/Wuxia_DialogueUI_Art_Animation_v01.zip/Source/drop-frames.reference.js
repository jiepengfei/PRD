function dropFrames(dx,dy){
 const height=Math.max(170,Math.min(300,-dy)),startX=-Math.min(32,Math.abs(dx)*.2),frames=[];
 for(let i=0;i<=20;i++){
  const t=i/20,y=-height+(height+10)*t*t,x=startX*(1-t)+3*t,angle=-7+9*t*t,scale=.55+.48*(1-Math.pow(1-t,1.4));
  frames.push({offset:t*.60,opacity:Math.min(1,t*12),transform:`translate(${x}px,${y}px) rotate(${angle}deg) scale(${scale})`});
 }
 frames.push(
  {offset:.64,opacity:1,transform:'translate(3px,12px) rotate(2.5deg) scale(1.05)',easing:'cubic-bezier(.12,.65,.3,1)'},
  {offset:.76,opacity:1,transform:'translate(-2px,-25px) rotate(-1.6deg) scale(.985)',easing:'cubic-bezier(.5,0,.85,.55)'},
  {offset:.86,opacity:1,transform:'translate(1px,3px) rotate(.8deg) scale(1.012)',easing:'ease-out'},
  {offset:.93,opacity:1,transform:'translate(0,-6px) rotate(-.35deg) scale(.997)',easing:'ease-in'},
  {offset:1,opacity:1,transform:'translate(0,0) rotate(0deg) scale(1)'}
 );
 return frames;
}
