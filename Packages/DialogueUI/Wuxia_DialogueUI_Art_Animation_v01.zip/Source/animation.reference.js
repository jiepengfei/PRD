
(()=>{
const root=document.getElementById('wuxia-dialogue-balanced');
const portrait=root.querySelector('.portrait-motion'),tag=root.querySelector('.name-motion'),panel=root.querySelector('.content-component'),speaker=root.querySelector('.speaker-component'),typed=root.querySelector('.typed-text'),reserve=root.querySelector('.text-reserve'),live=root.querySelector('.sr-only'),next=root.querySelector('.continue'),skip=root.querySelector('.skip'),end=root.querySelector('.end-note');
const lines=['村里的口粮，哪能交给他们。\n我去看看，你先通知乡亲们，别单独出村。','山贼既然已经到了村外，\n我便先去探个究竟。'];
let index=0,version=0,entering=false,animations=[];
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
function clear(){animations.forEach(a=>a.cancel());animations=[]}
function animate(el,frames,options){const a=el.animate(frames,{fill:'both',...options});animations.push(a);return a.finished.catch(()=>{})}
function setLine(){typed.textContent=lines[index];reserve.textContent=lines[index];live.textContent=lines[index]}
function dropFrames(dx,dy){
 const height=Math.max(170,Math.min(300,-dy)),startX=-Math.min(32,Math.abs(dx)*.2),frames=[];
 for(let i=0;i<=20;i++){
  const t=i/20,y=-height+(height+10)*t*t,x=startX*(1-t)+3*t,angle=-7+9*t*t,scale=.55+.48*(1-Math.pow(1-t,1.4));
  frames.push({offset:t*.60,opacity:Math.min(1,t*12),transform:`translate(${x}px,${y}px) rotate(${angle}deg) scale(${scale})`});
 }
 frames.push(
  {offset:.64,opacity:1,transform:'translate(3px,12px) rotate(2.5deg) scale(1.05)',easing:'cubic-bezier(.12,.65,.3,1)'},
  {offset:.76,opacity:1,transform:'translate(-2px,-25px) rotate(-1.6deg) scale(.985)',easing:'cubic-bezier(.5,0,.85,.55)'},
  {offset:.86,opacity:1,transform:'translate(1px,3px) rotate(.8deg) scale(1.012)',easing:'ease-out'},
  {offset:.93,opacity:1,transform:'translate(0,-6px) rotate(-.35deg) scale(.997)',easing:'ease-in'},
  {offset:1,opacity:1,transform:'translate(0,0) rotate(0deg) scale(1)'}
 );
 return frames;
}
async function enter(){
 version++;const mine=version;clear();index=0;entering=true;
 panel.hidden=false;speaker.hidden=false;skip.hidden=false;end.hidden=true;typed.textContent='';live.textContent='';reserve.textContent=lines[index];next.disabled=true;
 const p=portrait.getBoundingClientRect(),b=panel.getBoundingClientRect();const visibleW=p.height*(557/1075),imgLeft=p.left+(p.width-visibleW)/2;
 const head={x:imgLeft+visibleW*.58+42,y:p.top+p.height*.14-50};const origin={x:b.width*.05,y:b.height*.10};panel.style.transformOrigin="50% 100%";
 const dx=head.x-(b.left+origin.x),dy=head.y-(b.top+origin.y),below=p.height+85;
 root.dataset.launch=JSON.stringify({head,dx,dy,portraitBelow:below});
 if(!reduced())await Promise.all([
  animate(portrait,[
   {offset:0,opacity:1,transform:`translateY(${below}px) scale(1.08,.65)`,easing:'cubic-bezier(.5,0,.8,.4)'},
   {offset:.12,opacity:1,transform:`translateY(${below-12}px) scale(1.13,.65)`,easing:'cubic-bezier(.08,.65,.25,1)'},
   {offset:.42,opacity:1,transform:'translateY(-65px) scale(.95,1.08)',easing:'cubic-bezier(.55,0,.9,.5)'},
   {offset:.60,opacity:1,transform:'translateY(23px) scale(1.055,.94)',easing:'cubic-bezier(.15,.65,.3,1)'},
   {offset:.75,opacity:1,transform:'translateY(-22px) scale(.98,1.03)',easing:'ease-in'},
   {offset:.87,opacity:1,transform:'translateY(8px) scale(1.012,.99)',easing:'ease-out'},
   {offset:.95,opacity:1,transform:'translateY(-3px) scale(.997,1.004)',easing:'ease-in-out'},
   {offset:1,opacity:1,transform:'translateY(0) scale(1,1)'}
  ],{duration:1120,easing:'linear'}),
  animate(panel,dropFrames(dx,dy),{duration:1100,delay:400,easing:'linear'}),
  animate(tag,[{opacity:0,transform:'translateY(24px) rotate(-15deg) scale(.6)'},{offset:.70,opacity:1,transform:'translateY(-6px) rotate(4deg) scale(1.08)'},{offset:1,opacity:1,transform:'translateY(0) rotate(0deg) scale(1)'}],{duration:300,delay:1270,easing:'cubic-bezier(.15,.7,.25,1)'}),
  animate(next,[{opacity:0},{opacity:0}],{duration:1570})
 ]);
 if(mine!==version)return;setLine();
 if(!reduced())await Promise.all([animate(typed,[{opacity:0},{opacity:1}],{duration:170}),animate(next,[{opacity:0},{opacity:1}],{duration:170})]);
 if(mine!==version)return;entering=false;next.disabled=false;
}
async function advance(){if(entering)return;if(index===lines.length-1){finish();return}version++;const mine=version;entering=true;next.disabled=true;if(!reduced())await animate(typed,[{opacity:1},{opacity:0}],{duration:90});if(mine!==version)return;index++;setLine();if(!reduced())await animate(typed,[{opacity:0},{opacity:1}],{duration:180});if(mine!==version)return;entering=false;next.disabled=false}
async function finish(){version++;const mine=version,wasEntering=entering;clear();entering=true;if(!reduced()&&!wasEntering)await Promise.all([animate(panel,[{opacity:1,transform:'translate(0,0) rotate(0deg) scale(1)'},{opacity:0,transform:'translate(3px,230px) rotate(3deg) scale(1)'}],{duration:260,easing:'ease-in'}),animate(portrait,[{transform:'translateY(0)'},{transform:'translateY(650px)'}],{duration:330,easing:'ease-in'}),animate(tag,[{opacity:1},{opacity:0}],{duration:120})]);if(mine!==version)return;panel.hidden=true;speaker.hidden=true;skip.hidden=true;end.hidden=false;entering=false}
next.onclick=advance;panel.onclick=e=>{if(!e.target.closest('button'))advance()};skip.onclick=finish;root.querySelector('.replay').onclick=enter;enter();
})();

