# 对话UI美术包：缩小立绘＋下落放大版

当前定稿：人物缩小约22%；人物从下方弹出；对白框下落同时由55%放大，触底105%后回弹到100%。与当前v08静态图、动图采用同一布局。

## 使用顺序

1. 对照[静态效果](Reference/对话UI_定稿.png)和[动画效果](Reference/对话UI_定稿.gif)。
2. 看[资源导入与布局](Documentation/资源导入与布局.md)，把Assets下素材按目标工程原规范接入。
3. 按[动画接入说明](Documentation/动画接入说明.md)及[动画参数](Data/dialogue_animations.json)配置组件动画。
4. [资源清单](Assets/WuxiaVillage/Art/UI/Dialogue/manifest_dialogue.json)记录尺寸、透明通道和哈希；[布局参数](Data/dialogue_layout.json)记录参考画面中的实际矩形。

## 内容

8张独立PNG：场景背景、人物立绘、对白框、框后衬板、姓名牌、继续箭头、跳过按钮底、场景底部渐变。人物与图形均独立，姓名、台词、“继续”“跳过”用工程已有文字组件，不在图片中烘焙。

正式美术在Assets/WuxiaVillage/Art/UI/Dialogue，分Backgrounds/Portraits/Panels/Icons。Reference是对照图；Source是可编辑图形源稿和网页动效参考代码，均不需要整目录导入运行时。字体复用工程已有中文字体，本包不包含字体文件。

场景背景仅作对话参考，可换成游戏当前地图；开场动态练剑CG仍使用前一个视频包，本包不替代视频，不重复附带视频。当前只包含主角立绘，村民等说话人立绘未包含。

本包是美术与接入参数，不含已实现的Unity Prefab或运行时代码，未在目标Unity工程测试。动画GIF仅作参考，不作为UI运行时播放贴图。
