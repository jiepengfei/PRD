# 山道暮色 · 战斗人物动画接入包

配套战斗页面 v03。先读 [Unity 接入方案](Documentation/Unity接入方案.md)，再在现有战斗页对照 [待机 GIF](Reference/山道暮色-待机适中.gif) 和 [原地攻击与受击 GIF](Reference/山道暮色-原地人物动作.gif) 调整动作。

| 目录 | 资源 |
| --- | --- |
| `Art/Player/Swordsman/` | 主角待机与挥剑定格 |
| `Art/Enemies/ShieldBandit/` | 盾手待机与顶盾定格 |
| `Art/Enemies/SaberBandit/` | 刀手待机与横斩定格 |
| `Reference/` | 3.2 秒待机循环和 7.2 秒三人原地动作预览 |

每人有 `idle.png` 和 `attack.png` 两张透明 PNG。受击由 Unity 对原待机姿势施加局部顿挫和倾斜。GIF 用于对照动作与节奏，运行时使用透明 PNG 和动画曲线。
